﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Tools
{
	/// <summary>
	/// DES加密/解密类。
	/// </summary>
	public class DESEncrypt
	{

		#region --加密--

		/// <summary>
		/// 加密
		/// </summary>
		/// <param name="Text"></param>
		/// <returns></returns>
		public static string Encrypt(string Text)
		{
			return Encrypt(Text, "ncmvc");
		}
		/// <summary> 
		/// 加密数据 
		/// </summary> 
		/// <param name="Text"></param> 
		/// <param name="sKey"></param> 
		/// <returns></returns> 
		public static string Encrypt(string Text, string sKey)
		{
			try
			{
				DESCryptoServiceProvider des = new DESCryptoServiceProvider();
				byte[] inputByteArray;
				inputByteArray = Encoding.Default.GetBytes(Text);
				string md5SKey = Get32MD5One(sKey).Substring(0, 8);
				des.Key = ASCIIEncoding.ASCII.GetBytes(md5SKey);
				des.IV = ASCIIEncoding.ASCII.GetBytes(md5SKey);
				System.IO.MemoryStream ms = new System.IO.MemoryStream();
				CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);
				cs.Write(inputByteArray, 0, inputByteArray.Length);
				cs.FlushFinalBlock();
				StringBuilder ret = new StringBuilder();
				foreach (byte b in ms.ToArray())
				{
					ret.AppendFormat("{0:X2}", b);
				}
				return ret.ToString();
			}
			catch { return "error"; }
		}

		#endregion

		#region --解密--

		/// <summary>
		/// 解密
		/// </summary>
		/// <param name="Text"></param>
		/// <returns></returns>
		public static string Decrypt(string Text)
		{
			return Decrypt(Text, "ncmvc");
		}
		/// <summary> 
		/// 解密数据 
		/// </summary> 
		/// <param name="Text"></param> 
		/// <param name="sKey"></param> 
		/// <returns></returns> 
		public static string Decrypt(string Text, string sKey)
		{
			try
			{
				DESCryptoServiceProvider des = new DESCryptoServiceProvider();
				int len;
				len = Text.Length / 2;
				byte[] inputByteArray = new byte[len];
				int x, i;
				for (x = 0; x < len; x++)
				{
					i = Convert.ToInt32(Text.Substring(x * 2, 2), 16);
					inputByteArray[x] = (byte)i;
				}
				string md5SKey = Get32MD5One(sKey).Substring(0, 8);
				des.Key = ASCIIEncoding.ASCII.GetBytes(md5SKey);
				des.IV = ASCIIEncoding.ASCII.GetBytes(md5SKey);
				System.IO.MemoryStream ms = new System.IO.MemoryStream();
				CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);
				cs.Write(inputByteArray, 0, inputByteArray.Length);
				cs.FlushFinalBlock();
				return Encoding.Default.GetString(ms.ToArray());
			}
			catch { return "error"; }
		}

		#endregion

		/// <summary>
		/// 此代码示例通过创建哈希字符串适用于任何 MD5 哈希函数 （在任何平台） 上创建 32 个字符的十六进制格式哈希字符串
		/// 官网案例改编
		/// </summary>
		/// <param name="source"></param>
		/// <returns></returns>
		public static string Get32MD5One(string source)
		{
			using (MD5 md5Hash = MD5.Create())
			{
				byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(source));
				StringBuilder sBuilder = new StringBuilder();
				for (int i = 0; i < data.Length; i++)
				{
					sBuilder.Append(data[i].ToString("x2"));
				}

				string hash = sBuilder.ToString();
				return hash.ToUpper();
			}
		}
	}
}
