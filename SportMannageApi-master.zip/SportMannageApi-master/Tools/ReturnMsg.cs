﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace Tools
{
	enum status
	{
		error = 0,//错误
		susuccess = 1,//成功
		abnormal = 2 //异常
	}

	public class ReturnMsg
	{
		/// <summary>
		/// 返回成功
		/// </summary>
		/// <param name="data"></param>
		/// <param name="msg"></param>
		/// <returns></returns>
		public string Susuccess(object data ,string msg)
		{
			var res = new
			{
				Data = data,
				Status = status.susuccess,
				Msg = msg,
			};

			return JsonConvert.SerializeObject(res); 
		}

		/// <summary>
		/// 返回异常
		/// </summary>
		/// <param name="data"></param>
		/// <param name="msg"></param>
		/// <returns></returns>
		public string Abnormal(string msg)
		{
			var res = new
			{
				Data = "",
				Status = status.abnormal,
				Msg = msg,
			};

			return JsonConvert.SerializeObject(res);
		}

		/// <summary>
		/// 返回失败
		/// </summary>
		/// <param name="data"></param>
		/// <param name="msg"></param>
		/// <returns></returns>
		public string Error(string msg)
		{
			var res = new
			{
				Data = "",
				Status = status.error,
				Msg = msg,
			};

			return JsonConvert.SerializeObject(res);
		}
	}
}
