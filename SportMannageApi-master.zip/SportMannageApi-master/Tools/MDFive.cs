﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Tools
{
	public class MDFive
	{
		private static char[] constant =
		{
			'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
			'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'
		};
		public static string GenerateRandom(int Length)
		{
			System.Text.StringBuilder newRandom = new System.Text.StringBuilder(52);
			Random rd = new Random();
			for (int i = 0; i < Length; i++)
			{
				newRandom.Append(constant[rd.Next(52)]);
			}
			return newRandom.ToString();
		}

		public static string MD5Encrypt64(string password)
		{
			string cl = password;
			MD5 md5 = MD5.Create(); //实例化一个md5对像
			// 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
			byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
			return Convert.ToBase64String(s);
		}
	}
}
