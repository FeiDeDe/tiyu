namespace DotnetSpider.Core
{
    public enum ContentType
    {
        Auto,
        Json,
        Html
    }
}