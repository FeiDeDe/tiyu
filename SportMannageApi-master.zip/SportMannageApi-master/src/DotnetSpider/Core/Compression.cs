namespace DotnetSpider.Core
{
    public enum Compression
    {
        None = 0,
        Gzip = 1,
        Lz4 = 2
    }
}