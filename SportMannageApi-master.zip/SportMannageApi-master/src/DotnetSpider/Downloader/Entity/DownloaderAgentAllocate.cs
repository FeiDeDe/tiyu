namespace DotnetSpider.Downloader.Entity
{
	public class DownloaderAgentAllocate
	{
		/// <summary>
		/// 主键
		/// </summary>
		public long Id { get; set; }

		/// <summary>
		/// 下载器代理标识
		/// </summary>
		public string AgentId { get; set; }

		/// <summary>
		/// 任务标识
		/// </summary>
		public string OwnerId { get; set; }
	}
}