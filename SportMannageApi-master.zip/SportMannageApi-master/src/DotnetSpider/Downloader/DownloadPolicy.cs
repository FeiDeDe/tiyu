namespace DotnetSpider.Downloader
{
	public enum DownloadPolicy
	{
		Random,
		Chained
	}
}