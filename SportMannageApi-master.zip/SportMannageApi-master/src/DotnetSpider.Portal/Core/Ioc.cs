using System;

namespace DotnetSpider.Portal.Core
{
	public static class Ioc
	{
		public static IServiceProvider ServiceProvider;
	}
}