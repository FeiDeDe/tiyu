﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SportApi.Model
{
	public class Paging
	{
		/// <summary>
		/// 页码
		/// </summary>
		public int pageNum { get; set; }

		/// <summary>
		/// 页面大小
		/// </summary>
		public int pageSize { get; set; }
	}
}
