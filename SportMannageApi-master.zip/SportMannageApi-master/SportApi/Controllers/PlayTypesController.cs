﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayTypesController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();
		
        // GET: api/PlayTypes
        [HttpGet]
        public async Task<ActionResult<string>> GetPlayType(int pageNum, int pageSize)
        {
			var list = await _context.PlayType.Skip((pageNum - 1) * pageSize).Take(pageSize).ToListAsync();
			var count = await _context.PlayType.CountAsync();
			return tool.Susuccess(
				new {
					List = list,
					Count = count
				}
				, "获取成功！");
		}

        // GET: api/PlayTypes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<string>> GetPlayType(int id)
        {
            var playType = await _context.PlayType.FindAsync(id);

            if (playType == null)
            {
				return tool.Error("记录查询为空！");
			}

			return tool.Susuccess(playType, "获取成功！");
		}

        // PUT: api/PlayTypes/5
        [HttpPut("{id}")]
        public async Task<ActionResult<string>> PutPlayType(int id, PlayType playType)
        {
			if (id != playType.TypeId)
			{
				return tool.Error("记录查询为空！");
			}
			playType.AddTime = DateTime.Now.ToLocalTime();

			_context.Entry(playType).State = EntityState.Modified;

			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!PlayTypeExists(id))
				{
					return tool.Error("记录查询为空！");
				}
				else
				{
					throw;
				}
			}
        }

        // POST: api/PlayTypes
        [HttpPost]
        public async Task<ActionResult<string>> PostPlayType(PlayType playType)
        {
			playType.AddTime = DateTime.Now.ToLocalTime();
			_context.PlayType.Add(playType);
			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				return tool.Error("此数据添加异常！");
			}
		}

        // DELETE: api/PlayTypes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<string>> DeletePlayType(int id)
        {
			var playType = await _context.PlayType.FindAsync(id);
			if (playType == null)
			{
				return tool.Error("删除失败！");
			}

			_context.PlayType.Remove(playType);
			await _context.SaveChangesAsync();

			return tool.Susuccess(playType, "获取成功！");
		}

        private bool PlayTypeExists(int id)
        {
            return _context.PlayType.Any(e => e.TypeId == id);
        }
    }
}
