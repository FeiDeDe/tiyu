﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeambasemsgsController : ControllerBase
    {
        private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		// GET: api/Teambasemsgs
		[HttpGet]
        public async Task<ActionResult<string>> GetTeambasemsg(int pageNum, int pageSize)
        {
			var list = await _context.TeamBasemsg.Skip((pageNum - 1) * pageSize).Take(pageSize).ToListAsync();
			var count = await _context.TeamBasemsg.CountAsync();
			return tool.Susuccess(
				new
				{
					List = list,
					Count = count
				}
				, "获取成功！");
		}

        // GET: api/Teambasemsgs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<string>> GetTeambasemsg(int id)
        {
			var teambasemsg = await _context.TeamBasemsg.FindAsync(id);
			if (teambasemsg == null)
			{
				return tool.Error("记录查询为空！");
			}
			return tool.Susuccess(teambasemsg, "获取成功！");
        }
		
		// PUT: api/Teambasemsgs/5
		[HttpPut("{id}")]
        public async Task<ActionResult<string>> PutTeambasemsg(int id, TeamBasemsg teambasemsg)
        {
            if (id != teambasemsg.Id)
            {
				return tool.Error("记录查询为空！");
			}
			teambasemsg.EditTime = DateTime.Now;
			teambasemsg.BuildTime = teambasemsg.BuildTime.Value.ToLocalTime(); 
			_context.Entry(teambasemsg).State = EntityState.Modified;

            try
            {
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
            catch (DbUpdateConcurrencyException)
            {
                if (!TeambasemsgExists(id))
                {
					return tool.Error("此数据查询为空！");
				}
                else
                {
                    throw;
                }
            }
		}

        // POST: api/Teambasemsgs
        [HttpPost]
        public async Task<ActionResult<string>> PostTeambasemsg(TeamBasemsg teambasemsg)
        {
			teambasemsg.AddTime = DateTime.Now;
			teambasemsg.EditTime = DateTime.Now;
			teambasemsg.BuildTime = teambasemsg.BuildTime.Value.ToLocalTime();
			_context.TeamBasemsg.Add(teambasemsg);
						
			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				return tool.Error("此数据添加异常！");
			}
		}

        // DELETE: api/Teambasemsgs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<string>> DeleteTeambasemsg(int id)
        {


            var teambasemsg = await _context.TeamBasemsg.FindAsync(id);
            if (teambasemsg == null)
            {
                return tool.Error("记录查询为空！");
            }
            _context.TeamBasemsg.Remove(teambasemsg);
			return tool.Susuccess(await _context.SaveChangesAsync(),"删除提交成功！");
        }

        private bool TeambasemsgExists(int id)
        {
            return _context.TeamBasemsg.Any(e => e.Id == id);
        }
    }
}
