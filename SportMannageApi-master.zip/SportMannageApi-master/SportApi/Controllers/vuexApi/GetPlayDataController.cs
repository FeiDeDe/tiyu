﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers.vuexApi
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class GetPlayDataController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		// GET: api/GetPlayData
		[HttpGet]
        public async Task<ActionResult<string>> GetAsync(int pageNum, int pageSize)
        {
			var list = from a in _context.PlayMsg.Skip((pageNum - 1) * pageSize).Take(pageSize)
					   join b in _context.TypeFirst on a.PlayTypeFirstId equals b.TypeFirstId
					   join e in _context.TypeSecond on a.PlayTypeSecondId equals e.TypeSecondId
					   join f in _context.TypeThird on a.PlayTypeThirdId equals f.TypeThirdId
					   join c in _context.TeamBasemsg on a.TeamAid equals c.Id
					   join d in _context.TeamBasemsg on a.TeamBid equals d.Id
					   select new
					   {
						   playId = a.PlayId,
						   typeFirstName = b.TypeFirstName,
						   typeSecondName = e.TypeSecondName,
						   typeThirdName = f.TypeThirdName,
						   typeFirstId = b.TypeFirstId,
						   typeSecondId = e.TypeSecondId,
						   typeThirdId = f.TypeThirdId,
						   playTimeStart = a.PlayTimeStart,
						   playTimeEnd = a.PlayTimeEnd,
						   teamAId = a.TeamAid,
						   teamBId = a.TeamBid,
						   liveAddress1 = a.LiveAddress1,
						   liveAddress2 = a.LiveAddress2,
						   liveAddress3 = a.LiveAddress3,
						   liveAddress4 = a.LiveAddress4,
						   liveAddress5 = a.LiveAddress5,
						   teamAPoint = a.TeamApoint,
						   teamBPoint = a.TeamBpoint,
						   competitionStatus = a.CompetitionStatus,
						   //新增
						   teamAName = c.ChineseName,
						   teamBName = d.ChineseName
					   };
			var count = await _context.PlayMsg.CountAsync();
			return tool.Susuccess(
				new
				{
					List = list.ToListAsync(),
					Count = count
				}
				, "获取成功！");
		}

        // GET: api/GetPlayData/5
        [HttpGet("{id}", Name = "Get")]
        public async Task<ActionResult<string>> GetAsync(int id)
        {
			var playMsg = await _context.PlayMsg.FindAsync(id);

			if (playMsg == null)
			{
				return tool.Error("记录查询为空！");
			}

			return tool.Susuccess(playMsg, "获取成功！");
		}


		[HttpGet]
		public async Task<ActionResult<string>> GetPalyForType(string LV, int LVID, int pageNum, int pageSize)
		{

			var whereresultQ = from a in _context.PlayMsg.Where(a =>
								(LV == "First" ? a.PlayTypeFirstId == LVID : true) && (LV == "Second" ? a.PlayTypeSecondId == LVID : true) && (LV == "Thrid" ? a.PlayTypeThirdId == LVID : true)
								)select a;
					var list= await (from a in whereresultQ.Skip((pageNum - 1) * pageSize).Take(pageSize)
					   join b in _context.TypeFirst on a.PlayTypeFirstId equals b.TypeFirstId into ab
					   from ab1 in ab.DefaultIfEmpty()
					   join e in _context.TypeSecond on a.PlayTypeSecondId equals e.TypeSecondId into ae
					   from ae1 in ae.DefaultIfEmpty()
					   join f in _context.TypeThird on a.PlayTypeThirdId equals f.TypeThirdId into af
					   from af1 in af.DefaultIfEmpty()
					   join c in _context.TeamBasemsg on a.TeamAid equals c.Id into ac
					   from ac1 in ac.DefaultIfEmpty()
					   join d in _context.TeamBasemsg on a.TeamBid equals d.Id into ad
					   from ad1 in ad.DefaultIfEmpty()

					   select new
					   {
						   playId = a.PlayId,
						   typeFirstName =ab1!=null? ab1.TypeFirstName:"未知",
						   typeSecondName = ae1!=null? ae1.TypeSecondName : "未知",
						   typeThirdName = af1!=null?af1.TypeThirdName:"未知",
						   typeFirstId = a.PlayTypeFirstId,
						   typeSecondId = a.PlayTypeSecondId,
						   typeThirdId = a.PlayTypeThirdId,
						   playTimeStart = a.PlayTimeStart,
						   playTimeEnd = a.PlayTimeEnd,
						   teamAId = a.TeamAid,
						   teamBId = a.TeamBid,
						   liveAddress1 = a.LiveAddress1,
						   liveAddress2 = a.LiveAddress2,
						   liveAddress3 = a.LiveAddress3,
						   liveAddress4 = a.LiveAddress4,
						   liveAddress5 = a.LiveAddress5,
						   teamAPoint = a.TeamApoint,
						   teamBPoint = a.TeamBpoint,
						   competitionStatus = a.CompetitionStatus,
						   //新增
						   teamAName = ac1!=null? ac1.ChineseName:"未知",
						   teamBName = ad1!=null?ad1.ChineseName:"未知"
					   }).ToListAsync();
			var count = await whereresultQ.CountAsync();
			return tool.Susuccess(
				new
				{
					List = list,
					Count = count
				}
				, "获取成功！");
		}
	}
}
