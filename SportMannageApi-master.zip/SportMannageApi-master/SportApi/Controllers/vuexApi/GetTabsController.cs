﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers.vuexApi
{
	[Route("api/[controller]/[Action]")]
	[ApiController]
	public class GetTabsController : ControllerBase
	{
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		[HttpGet]
		public async Task<ActionResult<object>> GetReMen(int FNum,int SNum,int TNum)
		{
			try
			{
				//一
				var firstTypes = await _context.TypeFirst.OrderBy(a => a.TypeFirstSort).Select(a => new { typeID = a.TypeFirstId, typeName = a.TypeFirstName, LV = "First" }).Take(FNum).ToListAsync();
				//二
				var secondTypes = await _context.TypeSecond.OrderBy(a => a.TypeSecondSort).Select(a => new { typeID = a.TypeSecondId, typeName = a.TypeSecondName, LV = "Second" }).Take(SNum).ToListAsync();
				//三
				var thirdTypes = await _context.TypeThird.OrderBy(a => a.TypeThirdSort).Select(a => new { typeID = a.TypeThirdId, typeName = a.TypeThirdName, LV = "Thrid" }).Take(TNum).ToListAsync();
				firstTypes.AddRange(secondTypes);
				firstTypes.AddRange(thirdTypes);
				return tool.Susuccess(firstTypes, "获取成功");
			}
			catch (Exception e)
			{
				return tool.Susuccess(e.Message, "获取失败");
			}

		}

	}
}
