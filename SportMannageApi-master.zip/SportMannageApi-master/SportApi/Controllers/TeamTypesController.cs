﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamTypesController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		// GET: api/TeamTypes
		[HttpGet]
        public async Task<ActionResult<string>> GetTeamType()
        {
			return tool.Susuccess(await _context.TeamType.ToListAsync(), "获取成功！");
        }

        // GET: api/TeamTypes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<string>> GetTeamType(int id)
        {
            var teamType = await _context.TeamType.FindAsync(id);

            if (teamType == null)
            {
				return tool.Error("记录查询为空！");
			}
			return tool.Susuccess(teamType, "获取成功！");
        }

        // PUT: api/TeamTypes/5
        [HttpPut("{id}")]
        public async Task<ActionResult<string>> PutTeamType(int id, TeamType teamType)
        {
            if (id != teamType.TypeId)
            {
				return tool.Error("记录查询为空！");
			}
			teamType.AddTime = DateTime.Now.ToLocalTime();

			_context.Entry(teamType).State = EntityState.Modified;

            try
            {
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TeamTypeExists(id))
                {
					return tool.Error("记录查询为空！");
				}
                else
                {
                    throw;
                }
            }
		}

        // POST: api/TeamTypes
        [HttpPost]
        public async Task<ActionResult<string>> PostTeamType(TeamType teamType)
        {
			teamType.AddTime = DateTime.Now.ToLocalTime();
			_context.Entry(teamType).State = EntityState.Modified;
			_context.TeamType.Add(teamType);
			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				return tool.Error("此数据添加异常！");
			}
			
        }

        // DELETE: api/TeamTypes/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<string>> DeleteTeamType(int id)
        {
            var teamType = await _context.TeamType.FindAsync(id);
            if (teamType == null)
            {
				return tool.Error("删除失败！");
			}

            _context.TeamType.Remove(teamType);
            await _context.SaveChangesAsync();

			return tool.Susuccess(teamType, "获取成功！");
		}

        private bool TeamTypeExists(int id)
        {
            return _context.TeamType.Any(e => e.TypeId == id);
        }
    }
}
