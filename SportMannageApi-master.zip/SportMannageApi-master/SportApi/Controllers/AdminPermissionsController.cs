﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminPermissionsController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();

		// GET: api/AdminPermissions
		[HttpGet]
        public async Task<ActionResult<IEnumerable<AdminPermission>>> GetAdminPermission()
        {
            return await _context.AdminPermission.ToListAsync();
        }

        // GET: api/AdminPermissions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AdminPermission>> GetAdminPermission(uint id)
        {
            var adminPermission = await _context.AdminPermission.FindAsync(id);

            if (adminPermission == null)
            {
                return NotFound();
            }

            return adminPermission;
        }

        // PUT: api/AdminPermissions/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAdminPermission(uint id, AdminPermission adminPermission)
        {
            if (id != adminPermission.PermissionId)
            {
                return BadRequest();
            }

            _context.Entry(adminPermission).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AdminPermissionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AdminPermissions
        [HttpPost]
        public async Task<ActionResult<AdminPermission>> PostAdminPermission(AdminPermission adminPermission)
        {
            _context.AdminPermission.Add(adminPermission);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAdminPermission", new { id = adminPermission.PermissionId }, adminPermission);
        }

        // DELETE: api/AdminPermissions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<AdminPermission>> DeleteAdminPermission(uint id)
        {
            var adminPermission = await _context.AdminPermission.FindAsync(id);
            if (adminPermission == null)
            {
                return NotFound();
            }

            _context.AdminPermission.Remove(adminPermission);
            await _context.SaveChangesAsync();

            return adminPermission;
        }

        private bool AdminPermissionExists(uint id)
        {
            return _context.AdminPermission.Any(e => e.PermissionId == id);
        }
    }
}
