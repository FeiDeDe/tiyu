﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Model;
using Newtonsoft.Json.Linq;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetUserInfoController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		[HttpGet]
		public ActionResult<string> Get()
		{
			return tool.Error("方法不支持！"); ;
		}

		[HttpPost]
		public ActionResult<string> Post(JObject jo)
		{
			string res = "";
			string Token = jo["Token"].ToString();
			if (Token != "" && Token != null)
			{
				//解密用户名
				Token = Tools.DESEncrypt.Decrypt(Token);
				var u = _context.AdminUser.Where(c => c.Username == Token).FirstOrDefault();
				if (u != null)
				{
					res = tool.Susuccess(new
					{
						name = u.Realname,
						user_id = u.UserId,
						access = "",//用户权限
						token = u.Username,
						avatar = "https://avatars0.githubusercontent.com/u/20942571?s=460&v=4"
					}, "登录成功！");
				}
				else
				{
					res = tool.Error("用户不存在！");
				}
			}
			else
			{
				res = tool.Error("Token不能为空！");
			}			
			return res;
		}
	}
}
