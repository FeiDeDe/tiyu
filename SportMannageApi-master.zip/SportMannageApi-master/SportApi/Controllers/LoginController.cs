﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Model;
using Newtonsoft.Json;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		// GET: api/Login
		[HttpGet]
        public ActionResult<string> Get()
        {
            return tool.Error("方法不支持！"); ;
        }

        // POST: api/Login
		[HttpPost]
        public ActionResult<string> Post([FromBody] AdminUser user)
        {
			string res = "";
			var u = _context.AdminUser.Where(c => c.Username == user.Username).FirstOrDefault();
			if (u != null )
			{
				if (u.Password == Tools.MDFive.MD5Encrypt64(user.Password + u.Salt))
				{
					res = tool.Susuccess(new {
						token = Tools.DESEncrypt.Encrypt(u.Username),//用户名加密 token
					}, "登录成功！");
				}
				else
				{
					res = tool.Error("密码错误！");
				}
			}
			else
			{
				res = tool.Error("用户名不存在！");
			}
			return res;
		}
    }
}
