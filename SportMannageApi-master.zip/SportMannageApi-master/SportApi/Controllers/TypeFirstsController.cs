﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TypeFirstsController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();
		
        // GET: api/TypeFirsts
        [HttpGet]
        public async Task<ActionResult<string>> GetTypeFirst(int pageNum, int pageSize)
        {
			var list = await _context.TypeFirst.Skip((pageNum - 1) * pageSize).Take(pageSize).ToListAsync();
			var count = await _context.TypeFirst.CountAsync();
			return tool.Susuccess(
				new
				{
					List = list,
					Count = count
				}
				, "获取成功！");
		}

        // GET: api/TypeFirsts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<string>> GetTypeFirst(int id)
        {
			var type = await _context.TypeFirst.FindAsync(id);

			if (type == null)
			{
				return tool.Error("记录查询为空！");
			}
			return tool.Susuccess(type, "获取成功！");
        }

        // PUT: api/TypeFirsts/5
        [HttpPut("{id}")]
        public async Task<ActionResult<string>> PutTypeFirst(int id, TypeFirst typeFirst)
        {
			if (id != typeFirst.TypeFirstId)
			{
				return tool.Error("记录查询为空！");
			}

			_context.Entry(typeFirst).State = EntityState.Modified;

			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!TypeFirstExists(id))
				{
					return tool.Error("记录查询为空！");
				}
				else
				{
					throw;
				}
			}
		}

        // POST: api/TypeFirsts
        [HttpPost]
        public async Task<ActionResult<string>> PostTypeFirst(TypeFirst typeFirst)
        {			
			_context.Entry(typeFirst).State = EntityState.Modified;
			_context.TypeFirst.Add(typeFirst);
			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				return tool.Error("此数据添加异常！");
			}
		}

        // DELETE: api/TypeFirsts/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<string>> DeleteTypeFirst(int id)
        {
			var type = await _context.TypeFirst.FindAsync(id);
			if (type == null)
			{
				return tool.Error("删除失败！");
			}

			_context.TypeFirst.Remove(type);
			await _context.SaveChangesAsync();

			return tool.Susuccess(type, "获取成功！");
		}

        private bool TypeFirstExists(int id)
        {
            return _context.TypeFirst.Any(e => e.TypeFirstId == id);
        }
    }
}
