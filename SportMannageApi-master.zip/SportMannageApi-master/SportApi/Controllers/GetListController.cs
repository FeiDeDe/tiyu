﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]/{action}")]
	[ApiController]
	public class GetListController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		[HttpGet]
		public ActionResult<string> GetPlayTypeFirst()
		{
			var list = _context.TypeFirst.Select(c => new { value = c.TypeFirstId, label = c.TypeFirstName }).ToList();
			return tool.Susuccess(list, "获取成功！");
		}

		[HttpGet]
		public ActionResult<string> GetPlayTypeSecond()
		{
			var list = _context.TypeSecond.Select(c => new { value = c.TypeSecondId, label = c.TypeSecondName }).ToList();
			return tool.Susuccess(list, "获取成功！");
		}

		[HttpGet]
		public ActionResult<string> GetPlayTypeThird()
		{
			var list = _context.TypeThird.Select(c => new { value = c.TypeThirdId, label = c.TypeThirdName }).ToList();
			return tool.Susuccess(list, "获取成功！");
		}

		[HttpGet]
		public ActionResult<string> GetTeam()
		{
			var list = _context.TeamBasemsg.Select(c => new { value = c.Id, label = c.ChineseName }).ToList();
			return tool.Susuccess(list, "获取成功！");
		}
	}
}