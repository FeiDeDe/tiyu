﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TypeSecondsController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		
        // GET: api/TypeSeconds
        [HttpGet]
        public async Task<ActionResult<string>> GetTypeSecond(int pageNum, int pageSize)
        {
			var list = await _context.TypeSecond.Skip((pageNum - 1) * pageSize).Take(pageSize).ToListAsync();
			var count = await _context.TypeSecond.CountAsync();
			return tool.Susuccess(
				new
				{
					List = list,
					Count = count
				}
				, "获取成功！");
		}

        // GET: api/TypeSeconds/5
        [HttpGet("{id}")]
        public async Task<ActionResult<string>> GetTypeSecond(int id)
        {
			var type = await _context.TypeSecond.FindAsync(id);

			if (type == null)
			{
				return tool.Error("记录查询为空！");
			}
			return tool.Susuccess(type, "获取成功！");
		}

        // PUT: api/TypeSeconds/5
        [HttpPut("{id}")]
        public async Task<ActionResult<string>> PutTypeSecond(int id, TypeSecond typeSecond)
        {
			if (id != typeSecond.TypeSecondId)
			{
				return tool.Error("记录查询为空！");
			}

			_context.Entry(typeSecond).State = EntityState.Modified;

			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!TypeSecondExists(id))
				{
					return tool.Error("记录查询为空！");
				}
				else
				{
					throw;
				}
			}
		}

        // POST: api/TypeSeconds
        [HttpPost]
        public async Task<ActionResult<string>> PostTypeSecond(TypeSecond typeSecond)
        {
			_context.Entry(typeSecond).State = EntityState.Modified;
			_context.TypeSecond.Add(typeSecond);
			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				return tool.Error("此数据添加异常！");
			}
		}

        // DELETE: api/TypeSeconds/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<string>> DeleteTypeSecond(int id)
        {
			var type = await _context.TypeSecond.FindAsync(id);
			if (type == null)
			{
				return tool.Error("删除失败！");
			}

			_context.TypeSecond.Remove(type);
			await _context.SaveChangesAsync();

			return tool.Susuccess(type, "获取成功！");
		}

        private bool TypeSecondExists(int id)
        {
            return _context.TypeSecond.Any(e => e.TypeSecondId == id);
        }
    }
}
