﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminUserRolesController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();

		// GET: api/AdminUserRoles
		[HttpGet]
        public async Task<ActionResult<IEnumerable<AdminUserRole>>> GetAdminUserRole()
        {
            return await _context.AdminUserRole.ToListAsync();
        }

        // GET: api/AdminUserRoles/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AdminUserRole>> GetAdminUserRole(uint id)
        {
            var adminUserRole = await _context.AdminUserRole.FindAsync(id);

            if (adminUserRole == null)
            {
                return NotFound();
            }

            return adminUserRole;
        }

        // PUT: api/AdminUserRoles/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAdminUserRole(uint id, AdminUserRole adminUserRole)
        {
            if (id != adminUserRole.UserRoleId)
            {
                return BadRequest();
            }

            _context.Entry(adminUserRole).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AdminUserRoleExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AdminUserRoles
        [HttpPost]
        public async Task<ActionResult<AdminUserRole>> PostAdminUserRole(AdminUserRole adminUserRole)
        {
            _context.AdminUserRole.Add(adminUserRole);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAdminUserRole", new { id = adminUserRole.UserRoleId }, adminUserRole);
        }

        // DELETE: api/AdminUserRoles/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<AdminUserRole>> DeleteAdminUserRole(uint id)
        {
            var adminUserRole = await _context.AdminUserRole.FindAsync(id);
            if (adminUserRole == null)
            {
                return NotFound();
            }

            _context.AdminUserRole.Remove(adminUserRole);
            await _context.SaveChangesAsync();

            return adminUserRole;
        }

        private bool AdminUserRoleExists(uint id)
        {
            return _context.AdminUserRole.Any(e => e.UserRoleId == id);
        }
    }
}
