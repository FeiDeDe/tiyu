﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Model;
using Newtonsoft.Json.Linq;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class MessageController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		[HttpGet]
		public ActionResult<string> Get()
		{
			return tool.Error("方法不支持！"); ;
		}

		[HttpGet]
		public ActionResult<string> Count()
		{
			string res = "";
			if (true)
			{
				res = tool.Susuccess(1, "成功！");
			}
			else
			{
				res = tool.Error("用户不存在！");
			}
			return res;
		}

		[HttpGet]
		public ActionResult<string> Init()
		{
			string res = "";
			if (true)
			{
				res = tool.Susuccess(1, "成功！");
			}
			else
			{
				res = tool.Error("用户不存在！");
			}
			return res;
		}

		[HttpGet]
		public ActionResult<string> Content()
		{
			string res = "";
			if (true)
			{
				res = tool.Susuccess(1, "成功！");
			}
			else
			{
				res = tool.Error("用户不存在！");
			}
			return res;
		}

		[HttpGet]
		public ActionResult<string> Has_read()
		{
			string res = "";
			if (true)
			{
				res = tool.Susuccess(1, "成功！");
			}
			else
			{
				res = tool.Error("用户不存在！");
			}
			return res;
		}

		[HttpGet]
		public ActionResult<string> Remove_readed()
		{
			string res = "";
			if (true)
			{
				res = tool.Susuccess(1, "成功！");
			}
			else
			{
				res = tool.Error("用户不存在！");
			}
			return res;
		}

		[HttpGet]
		public ActionResult<string> Restore()
		{
			string res = "";
			if (true)
			{
				res = tool.Susuccess(1, "成功！");
			}
			else
			{
				res = tool.Error("用户不存在！");
			}
			return res;
		}
	}
}
