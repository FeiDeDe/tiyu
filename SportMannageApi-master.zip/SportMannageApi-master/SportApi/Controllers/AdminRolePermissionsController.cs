﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminRolePermissionsController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();

		// GET: api/AdminRolePermissions
		[HttpGet]
        public async Task<ActionResult<IEnumerable<AdminRolePermission>>> GetAdminRolePermission()
        {
            return await _context.AdminRolePermission.ToListAsync();
        }

        // GET: api/AdminRolePermissions/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AdminRolePermission>> GetAdminRolePermission(uint id)
        {
            var adminRolePermission = await _context.AdminRolePermission.FindAsync(id);

            if (adminRolePermission == null)
            {
                return NotFound();
            }

            return adminRolePermission;
        }

        // PUT: api/AdminRolePermissions/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAdminRolePermission(uint id, AdminRolePermission adminRolePermission)
        {
            if (id != adminRolePermission.RolePermissionId)
            {
                return BadRequest();
            }

            _context.Entry(adminRolePermission).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AdminRolePermissionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AdminRolePermissions
        [HttpPost]
        public async Task<ActionResult<AdminRolePermission>> PostAdminRolePermission(AdminRolePermission adminRolePermission)
        {
            _context.AdminRolePermission.Add(adminRolePermission);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAdminRolePermission", new { id = adminRolePermission.RolePermissionId }, adminRolePermission);
        }

        // DELETE: api/AdminRolePermissions/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<AdminRolePermission>> DeleteAdminRolePermission(uint id)
        {
            var adminRolePermission = await _context.AdminRolePermission.FindAsync(id);
            if (adminRolePermission == null)
            {
                return NotFound();
            }

            _context.AdminRolePermission.Remove(adminRolePermission);
            await _context.SaveChangesAsync();

            return adminRolePermission;
        }

        private bool AdminRolePermissionExists(uint id)
        {
            return _context.AdminRolePermission.Any(e => e.RolePermissionId == id);
        }
    }
}
