﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ErrorlogsController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		// GET: api/Errorlogs
		[HttpGet]
        public async Task<ActionResult<string>> GetErrorlog()
        {
            return tool.Susuccess(await _context.Errorlog.ToListAsync(),"获取成功！");
        }

        // GET: api/Errorlogs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Errorlog>> GetErrorlog(int id)
        {
            var errorlog = await _context.Errorlog.FindAsync(id);

            if (errorlog == null)
            {
                return NotFound();
            }

            return errorlog;
        }

        // PUT: api/Errorlogs/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutErrorlog(int id, Errorlog errorlog)
        {
            if (id != errorlog.ErrorLogId)
            {
                return BadRequest();
            }

            _context.Entry(errorlog).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ErrorlogExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Errorlogs
        [HttpPost]
        public async Task<ActionResult<string>> PostErrorlogAsync(Errorlog info)
        {
			string res = "";
			if (info.ErrorMsg != null && info.ErrorMsg != "")
			{
				info.AddTime = DateTime.Now;
				info.EditTime = DateTime.Now;
				_context.Errorlog.Add(info);
				res = tool.Susuccess(await _context.SaveChangesAsync(),"保存成功！");
			}
			else
			{
				res = tool.Error("ErrorMsg不存在！"); ;
			}

			return res;
		}

        // DELETE: api/Errorlogs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Errorlog>> DeleteErrorlog(int id)
        {
            var errorlog = await _context.Errorlog.FindAsync(id);
            if (errorlog == null)
            {
                return NotFound();
            }

            _context.Errorlog.Remove(errorlog);
            await _context.SaveChangesAsync();

            return errorlog;
        }

        private bool ErrorlogExists(int id)
        {
            return _context.Errorlog.Any(e => e.ErrorLogId == id);
        }
    }
}
