﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayMsgsController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();

		// GET: api/PlayMsgs
		[HttpGet]
        public async Task<ActionResult<string>> GetPlayMsg(int pageNum, int pageSize)
        {
			var list = from a in _context.PlayMsg.Skip((pageNum - 1) * pageSize).Take(pageSize)
					   join b in _context.TypeFirst on a.PlayTypeFirstId equals b.TypeFirstId
					   join e in _context.TypeSecond on a.PlayTypeSecondId equals e.TypeSecondId
					   join f in _context.TypeThird on a.PlayTypeThirdId equals f.TypeThirdId
					   join c in _context.TeamBasemsg on a.TeamAid equals c.Id
					   join d in _context.TeamBasemsg on a.TeamBid equals d.Id
					   select new
					   {
						   playId = a.PlayId,
						   typeFirstName = b.TypeFirstName,
						   typeSecondName = e.TypeSecondName,
						   typeThirdName = f.TypeThirdName,
						   typeFirstId = b.TypeFirstId,
						   typeSecondId = e.TypeSecondId,
						   typeThirdId = f.TypeThirdId,
						   playTimeStart = a.PlayTimeStart,
						   playTimeEnd = a.PlayTimeEnd,
						   teamAId = a.TeamAid,
						   teamBId = a.TeamBid,
						   liveAddress1 = a.LiveAddress1,
						   liveAddress2 = a.LiveAddress2,
						   liveAddress3 = a.LiveAddress3,
						   liveAddress4 = a.LiveAddress4,
						   liveAddress5 = a.LiveAddress5,
						   teamAPoint = a.TeamApoint,
						   teamBPoint = a.TeamBpoint,
						   competitionStatus = a.CompetitionStatus,
						   //新增
						   teamAName = c.ChineseName,
						   teamBName = d.ChineseName
					   };
			var count = await _context.PlayMsg.CountAsync();
			return tool.Susuccess(
				new
				{
					List = list,
					Count = count
				}
				, "获取成功！");
		}

        // GET: api/PlayMsgs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<string>> GetPlayMsg(int id)
        {
			var playMsg = await _context.PlayMsg.FindAsync(id);

			if (playMsg == null)
			{
				return tool.Error("记录查询为空！");
			}

			return tool.Susuccess(playMsg, "获取成功！");

        }

        // PUT: api/PlayMsgs/5
        [HttpPut("{id}")]
        public async Task<ActionResult<string>> PutPlayMsg(int id, PlayMsg playMsg)
        {
			if (id != playMsg.PlayId)
			{
				return tool.Error("记录查询为空！");
			}

			_context.Entry(playMsg).State = EntityState.Modified;

			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				if (!PlayMsgExists(id))
				{
					return tool.Error("记录查询为空！");
				}
				else
				{
					throw;
				}
			}
        }

        // POST: api/PlayMsgs
        [HttpPost]
        public async Task<ActionResult<string>> PostPlayMsg(PlayMsg playMsg)
        {
			_context.PlayMsg.Add(playMsg);
			try
			{
				return tool.Susuccess(await _context.SaveChangesAsync(), "获取成功！");
			}
			catch (DbUpdateConcurrencyException)
			{
				return tool.Error("此数据添加异常！");
			}
        }

        // DELETE: api/PlayMsgs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<string>> DeletePlayMsg(int id)
        {
			var playMsg = await _context.PlayMsg.FindAsync(id);
			if (playMsg == null)
			{
				return tool.Error("删除失败！");
			}

			_context.PlayMsg.Remove(playMsg);
			await _context.SaveChangesAsync();

			return tool.Susuccess(playMsg, "获取成功！");

        }

        private bool PlayMsgExists(int id)
        {
            return _context.PlayMsg.Any(e => e.PlayId == id);
        }
    }
}
