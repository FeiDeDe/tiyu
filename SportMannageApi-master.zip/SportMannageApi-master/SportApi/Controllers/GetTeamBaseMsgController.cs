﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Model;
using Tools;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GetTeamBaseMsgController : ControllerBase
    {
		sprotwebContext db = new sprotwebContext();
		ReturnMsg tool = new Tools.ReturnMsg();
				
		// GET: api/GetTeamBaseMsg
		[HttpGet]
        public string Get()
        {			
			string res = "";
			try
			{
				res = tool.Susuccess(db.Teambasemsg.Where(c => true).ToList(), "获取成功！");
			}
			catch (Exception ex)
			{
				res = tool.error(ex.Message);
			}
            return res;
        }

        // GET: api/GetTeamBaseMsg/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
			string res = "";
			try
			{
				res = tool.Susuccess(db.Teambasemsg.Where(c => c.Id == id).ToList(), "");
			}
			catch (Exception ex)
			{
				res = tool.error(ex.Message);
			}
			return res;
		}

        // POST: api/GetTeamBaseMsg
        [HttpPost]
        public void Post([FromBody] string value)
        {

        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public string Delete(int id)
        {
			string res = "";
			try
			{
				var del = db.Teambasemsg.Where(c => c.Id == id).FirstOrDefault();
				res = tool.Susuccess(db.Teambasemsg.Remove(del), "");
			}
			catch (Exception ex)
			{
				res = tool.error(ex.Message);
			}
			return res;
		}
    }
}
