﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Model;

namespace SportApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminLogsController : ControllerBase
    {
		private readonly sprotwebContext _context = new sprotwebContext();

		// GET: api/AdminLogs
		[HttpGet]
        public async Task<ActionResult<IEnumerable<AdminLog>>> GetAdminLog()
        {
            return await _context.AdminLog.ToListAsync();
        }

        // GET: api/AdminLogs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AdminLog>> GetAdminLog(int id)
        {
            var adminLog = await _context.AdminLog.FindAsync(id);

            if (adminLog == null)
            {
                return NotFound();
            }

            return adminLog;
        }

        // PUT: api/AdminLogs/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAdminLog(int id, AdminLog adminLog)
        {
            if (id != adminLog.LogId)
            {
                return BadRequest();
            }

            _context.Entry(adminLog).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AdminLogExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AdminLogs
        [HttpPost]
        public async Task<ActionResult<AdminLog>> PostAdminLog(AdminLog adminLog)
        {
            _context.AdminLog.Add(adminLog);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAdminLog", new { id = adminLog.LogId }, adminLog);
        }

        // DELETE: api/AdminLogs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<AdminLog>> DeleteAdminLog(int id)
        {
            var adminLog = await _context.AdminLog.FindAsync(id);
            if (adminLog == null)
            {
                return NotFound();
            }

            _context.AdminLog.Remove(adminLog);
            await _context.SaveChangesAsync();

            return adminLog;
        }

        private bool AdminLogExists(int id)
        {
            return _context.AdminLog.Any(e => e.LogId == id);
        }
    }
}
