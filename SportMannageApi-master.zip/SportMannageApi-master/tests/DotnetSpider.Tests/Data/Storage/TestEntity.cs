namespace DotnetSpider.Tests.Data.Storage
{
    public class TestEntity
    {
        
    }
}