﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class AdminUserRole
    {
        public uint UserRoleId { get; set; }
        public uint UserId { get; set; }
        public int? RoleId { get; set; }
    }
}
