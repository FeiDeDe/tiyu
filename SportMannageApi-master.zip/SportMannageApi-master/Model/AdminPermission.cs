﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class AdminPermission
    {
        public uint PermissionId { get; set; }
        public int? Pid { get; set; }
        public string Name { get; set; }
        public sbyte? Type { get; set; }
        public string PermissionValue { get; set; }
        public string Uri { get; set; }
        public string Icon { get; set; }
        public sbyte? Status { get; set; }
        public DateTime? Ctime { get; set; }
        public long? Orders { get; set; }
    }
}
