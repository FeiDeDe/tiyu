﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class TeamType
    {
        public int TypeId { get; set; }
        public string TypeName { get; set; }
        public DateTime? AddTime { get; set; }
        public int? Sort { get; set; }
    }
}
