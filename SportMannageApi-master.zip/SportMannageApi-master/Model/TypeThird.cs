﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class TypeThird
    {
        public int TypeThirdId { get; set; }
        public int? TypeSecondId { get; set; }
        public string TypeThirdName { get; set; }
        public int? TypeThirdSort { get; set; }
    }
}
