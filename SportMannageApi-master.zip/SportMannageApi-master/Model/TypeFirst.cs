﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class TypeFirst
    {
        public int TypeFirstId { get; set; }
        public string TypeFirstName { get; set; }
        public int? TypeFirstSort { get; set; }
    }
}
