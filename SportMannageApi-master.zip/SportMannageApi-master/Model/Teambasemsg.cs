﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class TeamBasemsg
    {
        public int Id { get; set; }
        public string ChineseName { get; set; }
        public string EnglishName { get; set; }
        public DateTime? BuildTime { get; set; }
        public string CourseCapacity { get; set; }
        public string Country { get; set; }
        public string Region { get; set; }
        public string City { get; set; }
        public string HomeTeam { get; set; }
        public string TeamValue { get; set; }
        public string TeamLogo { get; set; }
        public DateTime AddTime { get; set; }
        public DateTime? EditTime { get; set; }
    }
}
