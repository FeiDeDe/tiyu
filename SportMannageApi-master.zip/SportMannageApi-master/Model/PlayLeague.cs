﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class PlayLeague
    {
        public int LeagueId { get; set; }
        public string LeagueName { get; set; }
        public string LeagueArea { get; set; }
        public string LeagueType { get; set; }
        public string LeagueClass { get; set; }
        public DateTime? AddTime { get; set; }
    }
}
