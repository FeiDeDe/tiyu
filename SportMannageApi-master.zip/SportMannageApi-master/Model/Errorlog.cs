﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class Errorlog
    {
        public int ErrorLogId { get; set; }
        public string ApiType { get; set; }
        public string ControlerName { get; set; }
        public decimal? RequestTime { get; set; }
        public string ErrorMsg { get; set; }
        public string ErrorType { get; set; }
        public string Url { get; set; }
        public DateTime? AddTime { get; set; }
        public DateTime? EditTime { get; set; }
    }
}
