﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class AdminRole
    {
        public AdminRole()
        {
            AdminRolePermission = new HashSet<AdminRolePermission>();
        }

        public uint RoleId { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Ctime { get; set; }
        public long Orders { get; set; }

        public virtual ICollection<AdminRolePermission> AdminRolePermission { get; set; }
    }
}
