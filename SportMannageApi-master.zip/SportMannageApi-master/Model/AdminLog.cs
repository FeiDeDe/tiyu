﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class AdminLog
    {
        public int LogId { get; set; }
        public string Description { get; set; }
        public string Username { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? SpendTime { get; set; }
        public string BasePath { get; set; }
        public string Uri { get; set; }
        public string Url { get; set; }
        public string Method { get; set; }
        public string Parameter { get; set; }
        public string UserAgent { get; set; }
        public string Ip { get; set; }
        public string Result { get; set; }
        public string Permissions { get; set; }
    }
}
