﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class AdminRolePermission
    {
        public uint RolePermissionId { get; set; }
        public uint RoleId { get; set; }
        public uint PermissionId { get; set; }

        public virtual AdminRole Role { get; set; }
    }
}
