﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class PlayMsg
    {
        public int PlayId { get; set; }
        public int? PlayTypeThirdId { get; set; }
        public int? PlayTypeFirstId { get; set; }
        public int? PlayTypeSecondId { get; set; }
        public DateTime? PlayTimeStart { get; set; }
        public DateTime? PlayTimeEnd { get; set; }
        public int? TeamAid { get; set; }
        public int? TeamBid { get; set; }
        public string LiveAddress1 { get; set; }
        public string LiveAddress2 { get; set; }
        public string LiveAddress3 { get; set; }
        public string LiveAddress4 { get; set; }
        public string LiveAddress5 { get; set; }
        public string TeamApoint { get; set; }
        public string TeamBpoint { get; set; }
        public string CompetitionStatus { get; set; }
    }
}
