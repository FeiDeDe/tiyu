﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Model
{
    public partial class sprotwebContext : DbContext
    {
		public static string ConnectionString;

		public sprotwebContext()
        {
        }

        public sprotwebContext(DbContextOptions<sprotwebContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AdminLog> AdminLog { get; set; }
        public virtual DbSet<AdminPermission> AdminPermission { get; set; }
        public virtual DbSet<AdminRole> AdminRole { get; set; }
        public virtual DbSet<AdminRolePermission> AdminRolePermission { get; set; }
        public virtual DbSet<AdminUser> AdminUser { get; set; }
        public virtual DbSet<AdminUserRole> AdminUserRole { get; set; }
        public virtual DbSet<Errorlog> Errorlog { get; set; }
        public virtual DbSet<PlayMsg> PlayMsg { get; set; }
        public virtual DbSet<TeamBasemsg> TeamBasemsg { get; set; }
        public virtual DbSet<TypeFirst> TypeFirst { get; set; }
        public virtual DbSet<TypeSecond> TypeSecond { get; set; }
        public virtual DbSet<TypeThird> TypeThird { get; set; }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			if (!optionsBuilder.IsConfigured)
			{
				//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
				//optionsBuilder.UseMySql("server=localhost;userid=root;pwd=qazpl2010;port=3306;database=sprotweb;sslmode=none;");      
				optionsBuilder.UseMySql(ConnectionString);
			}
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AdminLog>(entity =>
            {
                entity.HasKey(e => e.LogId)
                    .HasName("PRIMARY");

                entity.ToTable("admin_log");

                entity.HasIndex(e => e.LogId)
                    .HasName("log_id");

                entity.Property(e => e.LogId)
                    .HasColumnName("log_id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.BasePath)
                    .HasColumnName("base_path")
                    .HasColumnType("varchar(500)");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.Ip)
                    .HasColumnName("ip")
                    .HasColumnType("varchar(30)");

                entity.Property(e => e.Method)
                    .HasColumnName("method")
                    .HasColumnType("varchar(10)");

                entity.Property(e => e.Parameter)
                    .HasColumnName("parameter")
                    .HasColumnType("mediumtext");

                entity.Property(e => e.Permissions)
                    .HasColumnName("permissions")
                    .HasColumnType("varchar(100)");

                entity.Property(e => e.Result)
                    .HasColumnName("result")
                    .HasColumnType("mediumtext");

                entity.Property(e => e.SpendTime)
                    .HasColumnName("spend_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.StartTime)
                    .HasColumnName("start_time")
                    .HasColumnType("datetime");

                entity.Property(e => e.Uri)
                    .HasColumnName("uri")
                    .HasColumnType("varchar(500)");

                entity.Property(e => e.Url)
                    .HasColumnName("url")
                    .HasColumnType("varchar(500)");

                entity.Property(e => e.UserAgent)
                    .HasColumnName("user_agent")
                    .HasColumnType("varchar(500)");

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasColumnType("varchar(20)");
            });

            modelBuilder.Entity<AdminPermission>(entity =>
            {
                entity.HasKey(e => e.PermissionId)
                    .HasName("PRIMARY");

                entity.ToTable("admin_permission");

                entity.Property(e => e.PermissionId).HasColumnName("permission_id");

                entity.Property(e => e.Ctime)
                    .HasColumnName("ctime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Icon)
                    .HasColumnName("icon")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasColumnType("varchar(20)");

                entity.Property(e => e.Orders)
                    .HasColumnName("orders")
                    .HasColumnType("bigint(20)");

                entity.Property(e => e.PermissionValue)
                    .HasColumnName("permission_value")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .HasColumnType("int(10)");

                entity.Property(e => e.Status)
                    .HasColumnName("status")
                    .HasColumnType("tinyint(4)");

                entity.Property(e => e.Type)
                    .HasColumnName("type")
                    .HasColumnType("tinyint(4)");

                entity.Property(e => e.Uri)
                    .HasColumnName("uri")
                    .HasColumnType("varchar(100)");
            });

            modelBuilder.Entity<AdminRole>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("PRIMARY");

                entity.ToTable("admin_role");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.Property(e => e.Ctime)
                    .HasColumnName("ctime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasColumnType("varchar(1000)");

                entity.Property(e => e.Name)
                    .HasColumnName("name")
                    .HasColumnType("varchar(20)");

                entity.Property(e => e.Orders)
                    .HasColumnName("orders")
                    .HasColumnType("bigint(20)");

                entity.Property(e => e.Title)
                    .HasColumnName("title")
                    .HasColumnType("varchar(20)");
            });

            modelBuilder.Entity<AdminRolePermission>(entity =>
            {
                entity.HasKey(e => e.RolePermissionId)
                    .HasName("PRIMARY");

                entity.ToTable("admin_role_permission");

                entity.HasIndex(e => e.RoleId)
                    .HasName("FK_Reference_23");

                entity.Property(e => e.RolePermissionId).HasColumnName("role_permission_id");

                entity.Property(e => e.PermissionId).HasColumnName("permission_id");

                entity.Property(e => e.RoleId).HasColumnName("role_id");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.AdminRolePermission)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Reference_23");
            });

            modelBuilder.Entity<AdminUser>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PRIMARY");

                entity.ToTable("admin_user");

                entity.Property(e => e.UserId).HasColumnName("user_id");

                entity.Property(e => e.Avatar)
                    .HasColumnName("avatar")
                    .HasColumnType("varchar(150)");

                entity.Property(e => e.Ctime)
                    .HasColumnName("ctime")
                    .HasColumnType("datetime");

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasColumnType("varchar(50)");

                entity.Property(e => e.Locked)
                    .HasColumnName("locked")
                    .HasColumnType("tinyint(4)");

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasColumnName("password")
                    .HasColumnType("varchar(32)");

                entity.Property(e => e.Phone)
                    .HasColumnName("phone")
                    .HasColumnType("varchar(20)");

                entity.Property(e => e.Realname)
                    .HasColumnName("realname")
                    .HasColumnType("varchar(20)");

                entity.Property(e => e.Salt)
                    .HasColumnName("salt")
                    .HasColumnType("varchar(32)");

                entity.Property(e => e.Sex)
                    .HasColumnName("sex")
                    .HasColumnType("tinyint(4)");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasColumnName("username")
                    .HasColumnType("varchar(20)");
            });

            modelBuilder.Entity<AdminUserRole>(entity =>
            {
                entity.HasKey(e => e.UserRoleId)
                    .HasName("PRIMARY");

                entity.ToTable("admin_user_role");

                entity.Property(e => e.UserRoleId).HasColumnName("user_role_id");

                entity.Property(e => e.RoleId)
                    .HasColumnName("role_id")
                    .HasColumnType("int(10)");

                entity.Property(e => e.UserId).HasColumnName("user_id");
            });

            modelBuilder.Entity<Errorlog>(entity =>
            {
                entity.ToTable("errorlog");

                entity.Property(e => e.ErrorLogId).HasColumnType("int(11)");

                entity.Property(e => e.AddTime).HasColumnType("datetime");

                entity.Property(e => e.ApiType).HasColumnType("varchar(255)");

                entity.Property(e => e.ControlerName).HasColumnType("varchar(255)");

                entity.Property(e => e.EditTime).HasColumnType("datetime");

                entity.Property(e => e.ErrorMsg).HasColumnType("varchar(255)");

                entity.Property(e => e.ErrorType).HasColumnType("varchar(255)");

                entity.Property(e => e.RequestTime).HasColumnType("decimal(10,0) unsigned");

                entity.Property(e => e.Url).HasColumnType("varchar(255)");
            });

            modelBuilder.Entity<PlayMsg>(entity =>
            {
                entity.HasKey(e => e.PlayId)
                    .HasName("PRIMARY");

                entity.ToTable("play_msg");

                entity.Property(e => e.PlayId)
                    .HasColumnName("playId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.CompetitionStatus)
                    .HasColumnName("competitionStatus")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.LiveAddress1)
                    .HasColumnName("liveAddress1")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.LiveAddress2)
                    .HasColumnName("liveAddress2")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.LiveAddress3)
                    .HasColumnName("liveAddress3")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.LiveAddress4)
                    .HasColumnName("liveAddress4")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.LiveAddress5)
                    .HasColumnName("liveAddress5")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.PlayTimeEnd)
                    .HasColumnName("playTimeEnd")
                    .HasColumnType("datetime");

                entity.Property(e => e.PlayTimeStart)
                    .HasColumnName("playTimeStart")
                    .HasColumnType("datetime");

                entity.Property(e => e.PlayTypeFirstId)
                    .HasColumnName("playTypeFirstId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.PlayTypeSecondId)
                    .HasColumnName("playTypeSecondId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.PlayTypeThirdId)
                    .HasColumnName("playTypeThirdId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TeamAid)
                    .HasColumnName("teamAId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TeamApoint)
                    .HasColumnName("teamAPoint")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.TeamBid)
                    .HasColumnName("teamBId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TeamBpoint)
                    .HasColumnName("teamBPoint")
                    .HasColumnType("varchar(255)");
            });

            modelBuilder.Entity<TeamBasemsg>(entity =>
            {
                entity.ToTable("team_basemsg");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .HasColumnType("int(11)");

                entity.Property(e => e.AddTime)
                    .HasColumnName("addTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.BuildTime)
                    .HasColumnName("buildTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.ChineseName)
                    .HasColumnName("chineseName")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.City)
                    .HasColumnName("city")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.Country)
                    .HasColumnName("country")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.CourseCapacity)
                    .HasColumnName("courseCapacity")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.EditTime)
                    .HasColumnName("editTime")
                    .HasColumnType("datetime");

                entity.Property(e => e.EnglishName)
                    .HasColumnName("englishName")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.HomeTeam)
                    .HasColumnName("homeTeam")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.Region)
                    .HasColumnName("region")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.TeamLogo)
                    .HasColumnName("teamLogo")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.TeamValue)
                    .HasColumnName("teamValue")
                    .HasColumnType("varchar(255)");
            });

            modelBuilder.Entity<TypeFirst>(entity =>
            {
                entity.ToTable("type_first");

                entity.Property(e => e.TypeFirstId)
                    .HasColumnName("typeFirstId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TypeFirstName)
                    .HasColumnName("typeFirstName")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.TypeFirstSort)
                    .HasColumnName("typeFirstSort")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<TypeSecond>(entity =>
            {
                entity.ToTable("type_second");

                entity.Property(e => e.TypeSecondId)
                    .HasColumnName("typeSecondId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TypeFirstId)
                    .HasColumnName("typeFirstId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TypeSecondName)
                    .HasColumnName("typeSecondName")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.TypeSecondSort)
                    .HasColumnName("typeSecondSort")
                    .HasColumnType("int(11)");
            });

            modelBuilder.Entity<TypeThird>(entity =>
            {
                entity.ToTable("type_third");

                entity.Property(e => e.TypeThirdId)
                    .HasColumnName("typeThirdId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TypeSecondId)
                    .HasColumnName("typeSecondId")
                    .HasColumnType("int(11)");

                entity.Property(e => e.TypeThirdName)
                    .HasColumnName("typeThirdName")
                    .HasColumnType("varchar(255)");

                entity.Property(e => e.TypeThirdSort)
                    .HasColumnName("typeThirdSort")
                    .HasColumnType("int(11)");
            });
        }
    }
}
