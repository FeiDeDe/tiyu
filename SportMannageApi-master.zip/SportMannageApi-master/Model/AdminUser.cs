﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class AdminUser
    {
        public uint UserId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Salt { get; set; }
        public string Realname { get; set; }
        public string Avatar { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public sbyte? Sex { get; set; }
        public sbyte? Locked { get; set; }
        public DateTime? Ctime { get; set; }
    }
}
