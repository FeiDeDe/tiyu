﻿using System;
using System.Collections.Generic;

namespace Model
{
    public partial class TypeSecond
    {
        public int TypeSecondId { get; set; }
        public int? TypeFirstId { get; set; }
        public string TypeSecondName { get; set; }
        public int? TypeSecondSort { get; set; }
    }
}
